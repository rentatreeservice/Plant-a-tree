# Public assets directory
